"use strict";
(() => {
  // src/shared/constants.ts
  var BRIDGE_SOURCE = "FRANZAI_BRIDGE";
  var BRIDGE_TIMEOUT_MS = 3e4;
  var MAX_BODY_BYTES = 5 * 1024 * 1024;
  var RUNTIME_MESSAGE_TIMEOUT_MS = 15e3;

  // src/shared/messages.ts
  var BG_MSG = {
    FETCH: "FRANZAI_FETCH",
    FETCH_ABORT: "FRANZAI_FETCH_ABORT",
    GET_SETTINGS: "FRANZAI_GET_SETTINGS",
    SET_SETTINGS: "FRANZAI_SET_SETTINGS",
    GET_LOGS: "FRANZAI_GET_LOGS",
    CLEAR_LOGS: "FRANZAI_CLEAR_LOGS",
    IS_KEY_SET: "FRANZAI_IS_KEY_SET",
    GET_KEY_NAMES: "FRANZAI_GET_KEY_NAMES",
    // Domain preference messages
    GET_DOMAIN_STATUS: "FRANZAI_GET_DOMAIN_STATUS",
    SET_DOMAIN_ENABLED: "FRANZAI_SET_DOMAIN_ENABLED",
    GET_ALL_DOMAIN_PREFS: "FRANZAI_GET_ALL_DOMAIN_PREFS",
    REPORT_META_TAG: "FRANZAI_REPORT_META_TAG",
    REMOVE_DOMAIN_PREF: "FRANZAI_REMOVE_DOMAIN_PREF",
    // Google OAuth messages
    GOOGLE_AUTH: "FRANZAI_GOOGLE_AUTH",
    GOOGLE_LOGOUT: "FRANZAI_GOOGLE_LOGOUT",
    GOOGLE_GET_STATE: "FRANZAI_GOOGLE_GET_STATE",
    GOOGLE_HAS_SCOPES: "FRANZAI_GOOGLE_HAS_SCOPES",
    GOOGLE_FETCH: "FRANZAI_GOOGLE_FETCH"
  };
  var BG_EVT = {
    LOGS_UPDATED: "FRANZAI_LOGS_UPDATED",
    SETTINGS_UPDATED: "FRANZAI_SETTINGS_UPDATED",
    DOMAIN_PREFS_UPDATED: "FRANZAI_DOMAIN_PREFS_UPDATED",
    GOOGLE_AUTH_UPDATED: "FRANZAI_GOOGLE_AUTH_UPDATED"
  };
  var PAGE_MSG = {
    FETCH_REQUEST: "FETCH_REQUEST",
    FETCH_ABORT: "FETCH_ABORT",
    FETCH_RESPONSE: "FETCH_RESPONSE",
    BRIDGE_READY: "BRIDGE_READY",
    KEY_CHECK_REQUEST: "KEY_CHECK_REQUEST",
    KEY_CHECK_RESPONSE: "KEY_CHECK_RESPONSE",
    KEYS_REQUEST: "KEYS_REQUEST",
    KEYS_RESPONSE: "KEYS_RESPONSE",
    KEYS_UPDATE: "KEYS_UPDATE",
    STATUS_REQUEST: "STATUS_REQUEST",
    STATUS_RESPONSE: "STATUS_RESPONSE",
    DOMAIN_ENABLED_UPDATE: "DOMAIN_ENABLED_UPDATE",
    // Google OAuth page messages
    GOOGLE_AUTH_REQUEST: "GOOGLE_AUTH_REQUEST",
    GOOGLE_AUTH_RESPONSE: "GOOGLE_AUTH_RESPONSE",
    GOOGLE_LOGOUT_REQUEST: "GOOGLE_LOGOUT_REQUEST",
    GOOGLE_LOGOUT_RESPONSE: "GOOGLE_LOGOUT_RESPONSE",
    GOOGLE_STATE_REQUEST: "GOOGLE_STATE_REQUEST",
    GOOGLE_STATE_RESPONSE: "GOOGLE_STATE_RESPONSE",
    GOOGLE_HAS_SCOPES_REQUEST: "GOOGLE_HAS_SCOPES_REQUEST",
    GOOGLE_HAS_SCOPES_RESPONSE: "GOOGLE_HAS_SCOPES_RESPONSE",
    GOOGLE_FETCH_REQUEST: "GOOGLE_FETCH_REQUEST",
    GOOGLE_FETCH_RESPONSE: "GOOGLE_FETCH_RESPONSE",
    GOOGLE_AUTH_UPDATE: "GOOGLE_AUTH_UPDATE"
  };

  // src/shared/logger.ts
  var LEVELS = {
    debug: 10,
    info: 20,
    warn: 30,
    error: 40,
    silent: 99
  };
  function resolveLevel(level) {
    if (level) return level;
    const raw = globalThis.__FRANZAI_LOG_LEVEL__;
    if (typeof raw === "string" && raw in LEVELS) return raw;
    return "info";
  }
  function createLogger(scope, level, c = console) {
    const chosen = resolveLevel(level);
    const min = LEVELS[chosen];
    const prefix = `[FranzAI Bridge/${scope}]`;
    return {
      debug: (...args) => {
        if (min <= LEVELS.debug) c.debug(prefix, ...args);
      },
      info: (...args) => {
        if (min <= LEVELS.info) c.info(prefix, ...args);
      },
      warn: (...args) => {
        if (min <= LEVELS.warn) c.warn(prefix, ...args);
      },
      error: (...args) => {
        if (min <= LEVELS.error) c.error(prefix, ...args);
      },
      log: (...args) => {
        if (min <= LEVELS.info) c.log(prefix, ...args);
      }
    };
  }

  // src/shared/runtime.ts
  var log = createLogger("runtime");
  function sendRuntimeMessage(message, options = {}) {
    const timeoutMs = options.timeoutMs ?? RUNTIME_MESSAGE_TIMEOUT_MS;
    return new Promise((resolve, reject) => {
      let done = false;
      const timeoutId = window.setTimeout(() => {
        if (done) return;
        done = true;
        reject(new Error(`Timeout waiting for runtime response after ${timeoutMs}ms`));
      }, timeoutMs);
      try {
        chrome.runtime.sendMessage(message, (resp) => {
          if (done) return;
          done = true;
          clearTimeout(timeoutId);
          const err = chrome.runtime.lastError;
          if (err) {
            log.warn("sendMessage failed", err.message || err);
            reject(err);
            return;
          }
          resolve(resp);
        });
      } catch (e) {
        if (done) return;
        done = true;
        clearTimeout(timeoutId);
        log.error("sendMessage threw", e);
        reject(e);
      }
    });
  }

  // src/contentScript.ts
  var log2 = createLogger("content");
  var BRIDGE_DISABLED_MESSAGE = 'Bridge is disabled for this domain. Enable it in the extension or add <meta name="franzai-bridge" content="enabled"> to your page.';
  var domainStatusCache = null;
  var domainStatusPromise = null;
  function makeFallbackStatus(reason) {
    return {
      installed: true,
      version: "unknown",
      domainEnabled: false,
      domainSource: "default",
      originAllowed: false,
      hasApiKeys: false,
      ready: false,
      reason
    };
  }
  async function fetchDomainStatus(domain) {
    if (domainStatusPromise) return domainStatusPromise;
    domainStatusPromise = (async () => {
      try {
        const resp = await sendRuntimeMessage({
          type: BG_MSG.GET_DOMAIN_STATUS,
          payload: { domain }
        });
        const status = resp.ok && resp.status ? resp.status : makeFallbackStatus(resp.error ?? "Failed to get status from extension");
        domainStatusCache = status;
        return status;
      } catch (e) {
        log2.warn("Failed to fetch domain status", e);
        const fallback = makeFallbackStatus("Failed to get status from extension");
        domainStatusCache = fallback;
        return fallback;
      } finally {
        domainStatusPromise = null;
      }
    })();
    return domainStatusPromise;
  }
  function isBridgeEnabled(status) {
    return status?.domainEnabled === true;
  }
  function sendBlockedFetchResponse(requestId, message) {
    const errorResponse = {
      requestId,
      ok: false,
      status: 0,
      statusText: "Bridge Disabled",
      headers: {},
      bodyText: "",
      elapsedMs: 0,
      error: message
    };
    window.postMessage(
      {
        source: BRIDGE_SOURCE,
        type: PAGE_MSG.FETCH_RESPONSE,
        payload: { ok: false, response: errorResponse, error: message }
      },
      "*"
    );
  }
  function sendBlockedGoogleFetchResponse(requestId, message) {
    window.postMessage(
      {
        source: BRIDGE_SOURCE,
        type: PAGE_MSG.GOOGLE_FETCH_RESPONSE,
        payload: {
          requestId,
          ok: false,
          status: 0,
          statusText: "Bridge Disabled",
          headers: {},
          bodyText: "",
          error: message
        }
      },
      "*"
    );
  }
  var port = chrome.runtime.connect({ name: "FRANZAI_CONTENT" });
  port.onMessage.addListener(async (evt) => {
    if (evt.type === BG_EVT.DOMAIN_PREFS_UPDATED) {
      const domain = window.location.hostname;
      try {
        const status = await fetchDomainStatus(domain);
        log2.info("Domain status updated, notifying page:", status.domainEnabled);
        window.postMessage(
          {
            source: BRIDGE_SOURCE,
            type: PAGE_MSG.DOMAIN_ENABLED_UPDATE,
            payload: {
              enabled: status.domainEnabled,
              source: status.domainSource
            }
          },
          "*"
        );
      } catch (e) {
        log2.warn("Failed to fetch updated domain status", e);
      }
    }
    if (evt.type === BG_EVT.SETTINGS_UPDATED) {
      try {
        const resp = await sendRuntimeMessage({
          type: BG_MSG.GET_KEY_NAMES
        });
        if (resp.ok && Array.isArray(resp.keys)) {
          window.postMessage(
            {
              source: BRIDGE_SOURCE,
              type: PAGE_MSG.KEYS_UPDATE,
              payload: { keys: resp.keys }
            },
            "*"
          );
        }
      } catch (e) {
        log2.warn("Failed to fetch updated key list", e);
      }
    }
    if (evt.type === BG_EVT.GOOGLE_AUTH_UPDATED) {
      window.postMessage(
        {
          source: BRIDGE_SOURCE,
          type: PAGE_MSG.GOOGLE_AUTH_UPDATE,
          payload: evt.payload
        },
        "*"
      );
    }
  });
  async function sendInitialDomainStatus() {
    const domain = window.location.hostname;
    const status = await fetchDomainStatus(domain);
    window.postMessage(
      {
        source: BRIDGE_SOURCE,
        type: PAGE_MSG.DOMAIN_ENABLED_UPDATE,
        payload: {
          enabled: status.domainEnabled,
          source: status.domainSource
        }
      },
      "*"
    );
  }
  sendInitialDomainStatus().catch((e) => {
    log2.warn("Failed to send initial domain status", e);
  });
  function detectMetaTag() {
    const meta = document.querySelector('meta[name="franzai-bridge"]');
    if (!meta) return false;
    const content = meta.getAttribute("content")?.toLowerCase();
    return content === "enabled" || content === "enabled-by-default" || content === "true";
  }
  function reportMetaTag() {
    const domain = window.location.hostname;
    const enabled = detectMetaTag();
    if (enabled) {
      log2.info("Meta tag detected, reporting to background:", domain);
      sendRuntimeMessage({
        type: BG_MSG.REPORT_META_TAG,
        payload: { domain, enabled: true }
      }).catch((e) => log2.warn("Failed to report meta tag", e));
    }
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", reportMetaTag);
  } else {
    reportMetaTag();
  }
  window.addEventListener("message", async (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== BRIDGE_SOURCE) return;
    if (data.type === PAGE_MSG.BRIDGE_READY) {
      log2.info("Bridge ready", data.payload?.version);
      return;
    }
    if (data.type === PAGE_MSG.FETCH_ABORT) {
      const requestId = data.payload?.requestId;
      if (!requestId) return;
      try {
        await sendRuntimeMessage({
          type: BG_MSG.FETCH_ABORT,
          payload: { requestId }
        });
      } catch (e) {
        log2.warn("Failed to forward abort", e);
      }
      return;
    }
    if (data.type === PAGE_MSG.KEY_CHECK_REQUEST) {
      const { checkId, keyName } = data.payload;
      if (!checkId || !keyName) return;
      try {
        const resp = await sendRuntimeMessage({
          type: BG_MSG.IS_KEY_SET,
          payload: { keyName }
        });
        window.postMessage(
          {
            source: BRIDGE_SOURCE,
            type: PAGE_MSG.KEY_CHECK_RESPONSE,
            payload: { checkId, isSet: resp.isSet }
          },
          "*"
        );
      } catch (e) {
        log2.warn("Failed to check key", e);
        window.postMessage(
          {
            source: BRIDGE_SOURCE,
            type: PAGE_MSG.KEY_CHECK_RESPONSE,
            payload: { checkId, isSet: false }
          },
          "*"
        );
      }
      return;
    }
    if (data.type === PAGE_MSG.KEYS_REQUEST) {
      const { keysId } = data.payload;
      if (!keysId) return;
      try {
        const resp = await sendRuntimeMessage({
          type: BG_MSG.GET_KEY_NAMES
        });
        window.postMessage(
          {
            source: BRIDGE_SOURCE,
            type: PAGE_MSG.KEYS_RESPONSE,
            payload: { keysId, keys: resp.ok ? resp.keys : [] }
          },
          "*"
        );
      } catch (e) {
        log2.warn("Failed to fetch key list", e);
        window.postMessage(
          {
            source: BRIDGE_SOURCE,
            type: PAGE_MSG.KEYS_RESPONSE,
            payload: { keysId, keys: [] }
          },
          "*"
        );
      }
      return;
    }
    if (data.type === PAGE_MSG.STATUS_REQUEST) {
      const { statusId } = data.payload;
      if (!statusId) return;
      const domain = window.location.hostname;
      try {
        const status = await fetchDomainStatus(domain);
        window.postMessage(
          {
            source: BRIDGE_SOURCE,
            type: PAGE_MSG.STATUS_RESPONSE,
            payload: { statusId, status }
          },
          "*"
        );
      } catch (e) {
        log2.warn("Failed to get status", e);
        const fallbackStatus = makeFallbackStatus("Failed to get status from extension");
        window.postMessage(
          {
            source: BRIDGE_SOURCE,
            type: PAGE_MSG.STATUS_RESPONSE,
            payload: { statusId, status: fallbackStatus }
          },
          "*"
        );
      }
      return;
    }
    if (data.type === PAGE_MSG.FETCH_REQUEST) {
      const req = data.payload;
      if (!req?.requestId) {
        log2.warn("Dropping request without requestId");
        return;
      }
      const domain = window.location.hostname;
      const status = domainStatusCache ?? await fetchDomainStatus(domain);
      if (!isBridgeEnabled(status)) {
        log2.info("Blocked fetch: bridge disabled for domain", domain);
        sendBlockedFetchResponse(req.requestId, BRIDGE_DISABLED_MESSAGE);
        return;
      }
      const payload = {
        ...req,
        pageOrigin: window.location.origin
      };
      try {
        const resp = await sendRuntimeMessage({
          type: BG_MSG.FETCH,
          payload
        }, {
          timeoutMs: BRIDGE_TIMEOUT_MS + 5e3
        });
        window.postMessage(
          {
            source: BRIDGE_SOURCE,
            type: PAGE_MSG.FETCH_RESPONSE,
            payload: resp
          },
          "*"
        );
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        const errorResponse = {
          requestId: req.requestId,
          ok: false,
          status: 0,
          statusText: "Bridge Error",
          headers: {},
          bodyText: "",
          elapsedMs: 0,
          error: message
        };
        log2.error("Bridge error reaching background", message);
        window.postMessage(
          {
            source: BRIDGE_SOURCE,
            type: PAGE_MSG.FETCH_RESPONSE,
            payload: {
              ok: false,
              response: errorResponse,
              error: `Failed to reach FranzAI Bridge background: ${message}`
            }
          },
          "*"
        );
      }
      return;
    }
    if (data.type === PAGE_MSG.GOOGLE_AUTH_REQUEST) {
      const { authId, scopes } = data.payload;
      try {
        const resp = await sendRuntimeMessage({ type: BG_MSG.GOOGLE_AUTH, payload: { scopes } });
        window.postMessage({
          source: BRIDGE_SOURCE,
          type: PAGE_MSG.GOOGLE_AUTH_RESPONSE,
          payload: { authId, success: resp.ok, state: resp.state }
        }, "*");
      } catch (e) {
        window.postMessage({
          source: BRIDGE_SOURCE,
          type: PAGE_MSG.GOOGLE_AUTH_RESPONSE,
          payload: { authId, success: false, error: String(e) }
        }, "*");
      }
      return;
    }
    if (data.type === PAGE_MSG.GOOGLE_LOGOUT_REQUEST) {
      const { logoutId } = data.payload;
      try {
        await sendRuntimeMessage({ type: BG_MSG.GOOGLE_LOGOUT });
        window.postMessage({
          source: BRIDGE_SOURCE,
          type: PAGE_MSG.GOOGLE_LOGOUT_RESPONSE,
          payload: { logoutId, success: true }
        }, "*");
      } catch {
        window.postMessage({
          source: BRIDGE_SOURCE,
          type: PAGE_MSG.GOOGLE_LOGOUT_RESPONSE,
          payload: { logoutId, success: false }
        }, "*");
      }
      return;
    }
    if (data.type === PAGE_MSG.GOOGLE_STATE_REQUEST) {
      const { stateId } = data.payload;
      try {
        const resp = await sendRuntimeMessage({ type: BG_MSG.GOOGLE_GET_STATE });
        window.postMessage({
          source: BRIDGE_SOURCE,
          type: PAGE_MSG.GOOGLE_STATE_RESPONSE,
          payload: { stateId, state: resp.state }
        }, "*");
      } catch {
        window.postMessage({
          source: BRIDGE_SOURCE,
          type: PAGE_MSG.GOOGLE_STATE_RESPONSE,
          payload: { stateId, state: { authenticated: false, email: null, scopes: [] } }
        }, "*");
      }
      return;
    }
    if (data.type === PAGE_MSG.GOOGLE_HAS_SCOPES_REQUEST) {
      const { scopesId, scopes } = data.payload;
      try {
        const resp = await sendRuntimeMessage({ type: BG_MSG.GOOGLE_HAS_SCOPES, payload: { scopes } });
        window.postMessage({
          source: BRIDGE_SOURCE,
          type: PAGE_MSG.GOOGLE_HAS_SCOPES_RESPONSE,
          payload: { scopesId, hasScopes: resp.hasScopes }
        }, "*");
      } catch {
        window.postMessage({
          source: BRIDGE_SOURCE,
          type: PAGE_MSG.GOOGLE_HAS_SCOPES_RESPONSE,
          payload: { scopesId, hasScopes: false }
        }, "*");
      }
      return;
    }
    if (data.type === PAGE_MSG.GOOGLE_FETCH_REQUEST) {
      const req = data.payload;
      const domain = window.location.hostname;
      const status = domainStatusCache ?? await fetchDomainStatus(domain);
      if (!isBridgeEnabled(status)) {
        log2.info("Blocked Google fetch: bridge disabled for domain", domain);
        sendBlockedGoogleFetchResponse(req.requestId, BRIDGE_DISABLED_MESSAGE);
        return;
      }
      try {
        const resp = await sendRuntimeMessage({ type: BG_MSG.GOOGLE_FETCH, payload: req });
        window.postMessage({
          source: BRIDGE_SOURCE,
          type: PAGE_MSG.GOOGLE_FETCH_RESPONSE,
          payload: resp
        }, "*");
      } catch (e) {
        window.postMessage({
          source: BRIDGE_SOURCE,
          type: PAGE_MSG.GOOGLE_FETCH_RESPONSE,
          payload: { requestId: req.requestId, ok: false, status: 0, statusText: "Error", headers: {}, bodyText: "", error: String(e) }
        }, "*");
      }
      return;
    }
  });
})();
//# sourceMappingURL=contentScript.js.map
