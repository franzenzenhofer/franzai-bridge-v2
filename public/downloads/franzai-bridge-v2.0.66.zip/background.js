"use strict";
(() => {
  // src/shared/messages.ts
  var BG_MSG = {
    FETCH: "FRANZAI_FETCH",
    FETCH_ABORT: "FRANZAI_FETCH_ABORT",
    GET_SETTINGS: "FRANZAI_GET_SETTINGS",
    SET_SETTINGS: "FRANZAI_SET_SETTINGS",
    GET_LOGS: "FRANZAI_GET_LOGS",
    CLEAR_LOGS: "FRANZAI_CLEAR_LOGS",
    IS_KEY_SET: "FRANZAI_IS_KEY_SET",
    GET_KEY_NAMES: "FRANZAI_GET_KEY_NAMES",
    // Domain preference messages
    GET_DOMAIN_STATUS: "FRANZAI_GET_DOMAIN_STATUS",
    SET_DOMAIN_ENABLED: "FRANZAI_SET_DOMAIN_ENABLED",
    GET_ALL_DOMAIN_PREFS: "FRANZAI_GET_ALL_DOMAIN_PREFS",
    REPORT_META_TAG: "FRANZAI_REPORT_META_TAG",
    REMOVE_DOMAIN_PREF: "FRANZAI_REMOVE_DOMAIN_PREF",
    // Google OAuth messages
    GOOGLE_AUTH: "FRANZAI_GOOGLE_AUTH",
    GOOGLE_LOGOUT: "FRANZAI_GOOGLE_LOGOUT",
    GOOGLE_GET_STATE: "FRANZAI_GOOGLE_GET_STATE",
    GOOGLE_HAS_SCOPES: "FRANZAI_GOOGLE_HAS_SCOPES",
    GOOGLE_FETCH: "FRANZAI_GOOGLE_FETCH"
  };
  var BG_EVT = {
    LOGS_UPDATED: "FRANZAI_LOGS_UPDATED",
    SETTINGS_UPDATED: "FRANZAI_SETTINGS_UPDATED",
    DOMAIN_PREFS_UPDATED: "FRANZAI_DOMAIN_PREFS_UPDATED",
    GOOGLE_AUTH_UPDATED: "FRANZAI_GOOGLE_AUTH_UPDATED"
  };

  // src/shared/defaults.ts
  var SETTINGS_VERSION = 3;
  var DEFAULT_SETTINGS = {
    settingsVersion: SETTINGS_VERSION,
    allowedOrigins: [
      "*"
      // Allow ALL origins by default - this extension is for circumventing CORS!
    ],
    allowedDestinations: [
      "*"
      // Allow ALL destinations by default - this extension is for circumventing CORS!
    ],
    env: {
      OPENAI_API_KEY: "",
      ANTHROPIC_API_KEY: "",
      GOOGLE_API_KEY: "",
      MISTRAL_API_KEY: ""
    },
    injectionRules: [],
    maxLogs: 200
  };

  // src/shared/constants.ts
  var BRIDGE_VERSION = "2.0.66";
  var FETCH_TIMEOUT_MS = 25e3;
  var MAX_BODY_BYTES = 5 * 1024 * 1024;
  var REQUEST_BODY_PREVIEW_LIMIT = 25e3;
  var RESPONSE_BODY_PREVIEW_LIMIT = 5e4;
  var MIN_LOGS_LIMIT = 10;
  var MAX_LOGS_LIMIT = 1e3;

  // src/shared/normalize.ts
  function toStringArray(value, fallback) {
    if (!Array.isArray(value)) return fallback;
    return value.filter((item) => typeof item === "string");
  }
  function toStringDict(value) {
    const out = {};
    if (!value || typeof value !== "object") return out;
    for (const [k, v] of Object.entries(value)) {
      if (typeof v === "string") out[k] = v;
    }
    return out;
  }
  function toRules(value) {
    if (!Array.isArray(value)) return [];
    const rules = [];
    for (const item of value) {
      if (!item || typeof item !== "object") continue;
      const rule = item;
      if (typeof rule.hostPattern !== "string") continue;
      rules.push({
        hostPattern: rule.hostPattern,
        injectHeaders: rule.injectHeaders ? toStringDict(rule.injectHeaders) : void 0,
        injectQuery: rule.injectQuery ? toStringDict(rule.injectQuery) : void 0
      });
    }
    return rules;
  }
  function clampNumber(value, fallback, min, max) {
    if (typeof value !== "number" || Number.isNaN(value)) return fallback;
    return Math.max(min, Math.min(max, Math.floor(value)));
  }
  function normalizeSettings(input) {
    const allowedOrigins = toStringArray(input?.allowedOrigins, DEFAULT_SETTINGS.allowedOrigins);
    const allowedDestinations = toStringArray(
      input?.allowedDestinations,
      DEFAULT_SETTINGS.allowedDestinations
    );
    const env = {
      ...DEFAULT_SETTINGS.env,
      ...toStringDict(input?.env)
    };
    const injectionRules = toRules(input?.injectionRules);
    const maxLogs = clampNumber(
      input?.maxLogs,
      DEFAULT_SETTINGS.maxLogs,
      MIN_LOGS_LIMIT,
      MAX_LOGS_LIMIT
    );
    return {
      settingsVersion: SETTINGS_VERSION,
      allowedOrigins,
      allowedDestinations,
      env,
      injectionRules,
      maxLogs
    };
  }

  // src/shared/logger.ts
  var LEVELS = {
    debug: 10,
    info: 20,
    warn: 30,
    error: 40,
    silent: 99
  };
  function resolveLevel(level) {
    if (level) return level;
    const raw = globalThis.__FRANZAI_LOG_LEVEL__;
    if (typeof raw === "string" && raw in LEVELS) return raw;
    return "info";
  }
  function createLogger(scope, level, c = console) {
    const chosen = resolveLevel(level);
    const min = LEVELS[chosen];
    const prefix = `[FranzAI Bridge/${scope}]`;
    return {
      debug: (...args) => {
        if (min <= LEVELS.debug) c.debug(prefix, ...args);
      },
      info: (...args) => {
        if (min <= LEVELS.info) c.info(prefix, ...args);
      },
      warn: (...args) => {
        if (min <= LEVELS.warn) c.warn(prefix, ...args);
      },
      error: (...args) => {
        if (min <= LEVELS.error) c.error(prefix, ...args);
      },
      log: (...args) => {
        if (min <= LEVELS.info) c.log(prefix, ...args);
      }
    };
  }

  // src/shared/storage.ts
  var log = createLogger("storage");
  var SETTINGS_KEY = "franzaiSettings";
  var LOGS_KEY = "franzaiLogs";
  var DOMAIN_PREFS_KEY = "franzaiDomainPrefs";
  function sessionStorageOrLocal() {
    const anyChrome = chrome;
    return anyChrome.storage?.session ?? chrome.storage.local;
  }
  function migrateSettings(oldSettings) {
    const newSettings = structuredClone(DEFAULT_SETTINGS);
    if (oldSettings?.env) {
      for (const [key, value] of Object.entries(oldSettings.env)) {
        if (value && value.trim() !== "") {
          newSettings.env[key] = value;
        }
      }
    }
    if (oldSettings?.injectionRules && oldSettings.injectionRules.length > 0) {
      newSettings.injectionRules = oldSettings.injectionRules;
    }
    log.info("Settings migrated to version", SETTINGS_VERSION, "preserving ENV vars and rules");
    return newSettings;
  }
  async function getSettings() {
    const data = await chrome.storage.local.get(SETTINGS_KEY);
    const stored = data[SETTINGS_KEY];
    const storedVersion = stored?.settingsVersion ?? 0;
    if (storedVersion < SETTINGS_VERSION) {
      log.info("Settings version outdated:", storedVersion, "\u2192", SETTINGS_VERSION, "- migrating");
      const migrated = migrateSettings(stored);
      await setSettings(migrated);
      return migrated;
    }
    return normalizeSettings(stored);
  }
  async function setSettings(settings) {
    const normalized = normalizeSettings(settings);
    await chrome.storage.local.set({ [SETTINGS_KEY]: normalized });
  }
  async function getLogs() {
    const store = sessionStorageOrLocal();
    const data = await store.get(LOGS_KEY);
    return data[LOGS_KEY] ?? [];
  }
  async function setLogs(logs) {
    const store = sessionStorageOrLocal();
    await store.set({ [LOGS_KEY]: logs });
  }
  async function appendLog(entry, maxLogs) {
    const logs = await getLogs();
    logs.unshift(entry);
    logs.length = Math.min(logs.length, maxLogs);
    await setLogs(logs);
  }
  async function clearLogs() {
    const store = sessionStorageOrLocal();
    await store.remove(LOGS_KEY);
  }
  async function getDomainPreferences() {
    const data = await chrome.storage.local.get(DOMAIN_PREFS_KEY);
    return data[DOMAIN_PREFS_KEY] ?? {};
  }
  async function setDomainPreferences(prefs) {
    await chrome.storage.local.set({ [DOMAIN_PREFS_KEY]: prefs });
  }
  async function getDomainPreference(domain) {
    const prefs = await getDomainPreferences();
    return prefs[domain] ?? null;
  }
  async function setDomainPreference(domain, enabled, source) {
    const prefs = await getDomainPreferences();
    const existing = prefs[domain];
    if (existing?.source === "user" && source === "meta") {
      return;
    }
    prefs[domain] = {
      enabled,
      source,
      lastModified: Date.now()
    };
    await setDomainPreferences(prefs);
  }
  async function removeDomainPreference(domain) {
    const prefs = await getDomainPreferences();
    delete prefs[domain];
    await setDomainPreferences(prefs);
  }

  // src/shared/wildcard.ts
  function wildcardToRegExp(pattern) {
    const escaped = pattern.trim().replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*");
    return new RegExp(`^${escaped}$`, "i");
  }

  // src/shared/providers.ts
  function builtinProviderRules() {
    return [
      {
        hostPattern: "api.openai.com",
        injectHeaders: {
          Authorization: "Bearer ${OPENAI_API_KEY}"
        }
      },
      {
        hostPattern: "api.anthropic.com",
        injectHeaders: {
          "x-api-key": "${ANTHROPIC_API_KEY}",
          "anthropic-version": "2023-06-01"
          // Hardcoded - users don't need to configure this
        }
      },
      {
        hostPattern: "generativelanguage.googleapis.com",
        injectHeaders: {
          "x-goog-api-key": "${GOOGLE_API_KEY}"
        }
      },
      {
        hostPattern: "api.mistral.ai",
        injectHeaders: {
          Authorization: "Bearer ${MISTRAL_API_KEY}"
        }
      }
    ];
  }
  function expandTemplate(input, env) {
    return input.replace(/\$\{([A-Z0-9_]+)\}/g, (_, name) => env[name] ?? "");
  }
  function headersToObject(headers) {
    const out = {};
    if (!headers) return out;
    if (headers instanceof Headers) {
      headers.forEach((value, key) => {
        out[key] = value;
      });
      return out;
    }
    if (Array.isArray(headers)) {
      for (const [k, v] of headers) out[k] = v;
      return out;
    }
    for (const [k, v] of Object.entries(headers)) {
      out[k] = String(v);
    }
    return out;
  }
  function hasHeader(headers, name) {
    const n = name.toLowerCase();
    return Object.keys(headers).some((k) => k.toLowerCase() === n);
  }

  // src/shared/ids.ts
  function makeId(prefix) {
    if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
      return `${prefix}_${crypto.randomUUID()}`;
    }
    return `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  }

  // src/background/fetchHandler.ts
  var log2 = createLogger("fetch");
  var inFlight = /* @__PURE__ */ new Map();
  var abortedByPage = /* @__PURE__ */ new Set();
  function isBinaryBody(body) {
    return typeof body === "object" && body !== null && "__binary" in body && body.__binary === true;
  }
  function base64ToUint8Array(base64) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
  }
  function decodeBinaryBody(body) {
    return base64ToUint8Array(body.base64);
  }
  function abortFetch(requestId) {
    abortedByPage.add(requestId);
    const controller = inFlight.get(requestId);
    if (controller) controller.abort();
  }
  function isDestinationAllowed(url, allowedDestinations) {
    const full = url.toString();
    const host = url.hostname;
    for (const pat of allowedDestinations) {
      const p = pat.trim();
      if (!p) continue;
      if (p.includes("://")) {
        if (wildcardToRegExp(p).test(full)) return true;
      } else {
        if (wildcardToRegExp(p).test(host)) return true;
      }
    }
    return false;
  }
  function applyInjectionRules(args) {
    const { url, headers, env, rules } = args;
    for (const rule of rules) {
      const hostRe = wildcardToRegExp(rule.hostPattern);
      if (!hostRe.test(url.hostname)) continue;
      if (rule.injectHeaders) {
        for (const [hk, hvTemplate] of Object.entries(rule.injectHeaders)) {
          if (hasHeader(headers, hk)) continue;
          const value = expandTemplate(hvTemplate, env).trim();
          if (value) headers[hk] = value;
        }
      }
      if (rule.injectQuery) {
        for (const [qk, qvTemplate] of Object.entries(rule.injectQuery)) {
          if (url.searchParams.has(qk)) continue;
          const value = expandTemplate(qvTemplate, env).trim();
          if (value) url.searchParams.set(qk, value);
        }
      }
    }
  }
  function previewBody(body, max) {
    if (body == null) return "";
    if (isBinaryBody(body)) return `[binary body ${body.byteLength} bytes]`;
    if (body instanceof Uint8Array) return `[binary body ${body.byteLength} bytes]`;
    if (body instanceof ArrayBuffer) return `[binary body ${body.byteLength} bytes]`;
    if (typeof body !== "string") return `[${typeof body} body omitted]`;
    if (body.length <= max) return body;
    return body.slice(0, max) + `

...[truncated, total ${body.length} chars]`;
  }
  function makeErrorResponse(requestId, statusText, message, elapsedMs) {
    return { requestId, ok: false, status: 0, statusText, headers: {}, bodyText: "", elapsedMs, error: message };
  }
  async function finalizeWithError(args) {
    const { requestId, statusText, message, started, logEntry, maxLogs, broadcast: broadcast2 } = args;
    const elapsedMs = Date.now() - started;
    logEntry.status = 0;
    logEntry.statusText = statusText;
    logEntry.error = message;
    logEntry.elapsedMs = elapsedMs;
    await appendLog(logEntry, maxLogs);
    broadcast2({ type: BG_EVT.LOGS_UPDATED });
    return { ok: false, response: makeErrorResponse(requestId, statusText, message, elapsedMs), error: message };
  }
  async function handleFetch(payload, tabId, broadcast2) {
    const settings = await getSettings();
    const started = Date.now();
    log2.info("FRANZAI_FETCH", { requestId: payload.requestId, tabId, pageOrigin: payload.pageOrigin, url: payload.url });
    const init = payload.init ?? {};
    const method = (init.method ?? "GET").toUpperCase();
    const requestHeaders = headersToObject(init.headers);
    const logEntry = {
      id: makeId("log"),
      requestId: payload.requestId,
      ts: Date.now(),
      tabId,
      pageOrigin: payload.pageOrigin,
      url: payload.url,
      method,
      requestHeaders,
      requestBodyPreview: previewBody(init.body, REQUEST_BODY_PREVIEW_LIMIT)
    };
    if (!payload.pageOrigin) {
      log2.warn("Blocked fetch: no origin provided");
      return finalizeWithError({ requestId: payload.requestId, statusText: "Blocked", message: "Blocked: no page origin provided.", started, logEntry, maxLogs: settings.maxLogs, broadcast: broadcast2 });
    }
    let url;
    try {
      url = new URL(payload.url);
    } catch {
      log2.warn("Blocked fetch: invalid URL", payload.url);
      return finalizeWithError({ requestId: payload.requestId, statusText: "Bad URL", message: `Invalid URL: ${payload.url}`, started, logEntry, maxLogs: settings.maxLogs, broadcast: broadcast2 });
    }
    logEntry.url = url.toString();
    if (!isDestinationAllowed(url, settings.allowedDestinations)) {
      log2.warn("Blocked fetch: destination not allowed", url.hostname);
      return finalizeWithError({ requestId: payload.requestId, statusText: "Blocked", message: `Blocked: destination not allowed (${url.hostname}).`, started, logEntry, maxLogs: settings.maxLogs, broadcast: broadcast2 });
    }
    const allRules = [...builtinProviderRules(), ...settings.injectionRules];
    applyInjectionRules({ url, headers: requestHeaders, env: settings.env, rules: allRules });
    let fetchBody;
    if (init.body != null) {
      if (isBinaryBody(init.body)) {
        fetchBody = decodeBinaryBody(init.body);
      } else {
        fetchBody = init.body;
      }
    }
    const fetchInit = {
      method,
      headers: requestHeaders,
      body: fetchBody,
      redirect: init.redirect,
      credentials: init.credentials,
      cache: init.cache,
      referrer: init.referrer,
      referrerPolicy: init.referrerPolicy,
      integrity: init.integrity,
      keepalive: init.keepalive
    };
    const controller = new AbortController();
    let timedOut = false;
    const timeoutId = setTimeout(() => {
      timedOut = true;
      controller.abort();
    }, FETCH_TIMEOUT_MS);
    inFlight.set(payload.requestId, controller);
    try {
      const res = await fetch(url.toString(), { ...fetchInit, signal: controller.signal });
      const headersObj = {};
      res.headers.forEach((value, key) => {
        headersObj[key] = value;
      });
      const bodyText = await res.text();
      const elapsedMs = Date.now() - started;
      logEntry.status = res.status;
      logEntry.statusText = res.statusText;
      logEntry.responseHeaders = headersObj;
      logEntry.responseBodyPreview = previewBody(bodyText, RESPONSE_BODY_PREVIEW_LIMIT);
      logEntry.elapsedMs = elapsedMs;
      await appendLog(logEntry, settings.maxLogs);
      broadcast2({ type: BG_EVT.LOGS_UPDATED });
      const responseToPage = {
        requestId: payload.requestId,
        ok: res.ok,
        status: res.status,
        statusText: res.statusText,
        headers: headersObj,
        bodyText,
        elapsedMs
      };
      log2.info("Fetch completed", { requestId: payload.requestId, url: url.toString(), status: res.status, elapsedMs });
      return { ok: true, response: responseToPage };
    } catch (e) {
      const elapsedMs = Date.now() - started;
      const err = e instanceof Error ? e.message : String(e);
      const isAbort = e instanceof Error && e.name === "AbortError";
      let message = err;
      let statusText = "Network Error";
      if (isAbort && timedOut) {
        statusText = "Timeout";
        message = `Timed out after ${FETCH_TIMEOUT_MS}ms`;
      } else if (isAbort && abortedByPage.has(payload.requestId)) {
        statusText = "Aborted";
        message = "Aborted by caller";
      }
      logEntry.error = message;
      logEntry.statusText = statusText;
      logEntry.elapsedMs = elapsedMs;
      await appendLog(logEntry, settings.maxLogs);
      broadcast2({ type: BG_EVT.LOGS_UPDATED });
      const responseToPage = {
        requestId: payload.requestId,
        ok: false,
        status: 0,
        statusText,
        headers: {},
        bodyText: "",
        elapsedMs,
        error: message
      };
      log2.error("Fetch failed", { requestId: payload.requestId, statusText, message });
      return { ok: false, response: responseToPage, error: message };
    } finally {
      clearTimeout(timeoutId);
      inFlight.delete(payload.requestId);
      abortedByPage.delete(payload.requestId);
    }
  }

  // src/shared/googleScopes.ts
  var V1_SCOPES = {
    WEBMASTERS: "https://www.googleapis.com/auth/webmasters",
    WEBMASTERS_READONLY: "https://www.googleapis.com/auth/webmasters.readonly",
    ANALYTICS_READONLY: "https://www.googleapis.com/auth/analytics.readonly",
    ANALYTICS: "https://www.googleapis.com/auth/analytics"
  };
  var SCOPE_ALIASES = {
    "webmasters": V1_SCOPES.WEBMASTERS,
    "webmasters.readonly": V1_SCOPES.WEBMASTERS_READONLY,
    "searchconsole": V1_SCOPES.WEBMASTERS_READONLY,
    "search-console": V1_SCOPES.WEBMASTERS_READONLY,
    "analytics": V1_SCOPES.ANALYTICS,
    "analytics.readonly": V1_SCOPES.ANALYTICS_READONLY
  };
  var ALL_VALID_SCOPES = new Set(Object.values(V1_SCOPES));
  function normalizeScope(scope) {
    const trimmed = scope.trim().toLowerCase();
    return SCOPE_ALIASES[trimmed] ?? scope;
  }
  function normalizeScopeInput(input) {
    if (!input) {
      return [V1_SCOPES.WEBMASTERS_READONLY];
    }
    const arr = Array.isArray(input) ? input : [input];
    return arr.map(normalizeScope);
  }
  function scopesInclude(granted, required) {
    const grantedSet = new Set(granted);
    return required.every((s) => grantedSet.has(s));
  }

  // src/shared/googleAuth.ts
  var STORAGE_KEY = "google_auth";
  var TOKEN_REFRESH_BUFFER_MS = 5 * 60 * 1e3;
  var TOKEN_LIFETIME_MS = 60 * 60 * 1e3;
  function emptyState() {
    return { authenticated: false, email: null, scopes: [], accessToken: null, tokenExpiresAt: null };
  }
  function getPublicAuthState(state) {
    return { authenticated: state.authenticated, email: state.email, scopes: state.scopes };
  }
  var storage = {
    async get() {
      const result = await chrome.storage.local.get(STORAGE_KEY);
      return result[STORAGE_KEY] ?? emptyState();
    },
    async set(state) {
      await chrome.storage.local.set({ [STORAGE_KEY]: state });
    },
    async clear() {
      await chrome.storage.local.remove(STORAGE_KEY);
    }
  };
  function isExpiringSoon(expiresAt) {
    if (!expiresAt) return true;
    return Date.now() > expiresAt - TOKEN_REFRESH_BUFFER_MS;
  }
  function removeCachedToken(token) {
    return new Promise((resolve) => {
      chrome.identity.removeCachedAuthToken({ token }, () => resolve());
    });
  }
  function requestToken(scopes, interactive) {
    return new Promise((resolve) => {
      chrome.identity.getAuthToken({ interactive, scopes }, (token) => {
        if (chrome.runtime.lastError || !token) {
          console.error("[FranzAI] Token request failed:", chrome.runtime.lastError?.message);
          resolve(null);
          return;
        }
        resolve(token);
      });
    });
  }
  async function fetchUserEmail(token) {
    const resp = await fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (!resp.ok) return null;
    const data = await resp.json();
    return data.email ?? null;
  }
  async function authenticateGoogle(requestedScopes) {
    const scopes = normalizeScopeInput(requestedScopes);
    const current = await storage.get();
    if (current.authenticated && scopesInclude(current.scopes, scopes)) {
      return current;
    }
    const allScopes = [.../* @__PURE__ */ new Set([...current.scopes, ...scopes])];
    const token = await requestToken(allScopes, true);
    if (!token) return emptyState();
    const email = await fetchUserEmail(token);
    const newState = {
      authenticated: true,
      email,
      scopes: allScopes,
      accessToken: token,
      tokenExpiresAt: Date.now() + TOKEN_LIFETIME_MS
    };
    await storage.set(newState);
    return newState;
  }
  async function logoutGoogle() {
    const state = await storage.get();
    if (state.accessToken) {
      await removeCachedToken(state.accessToken);
    }
    await storage.clear();
  }
  async function getValidAccessToken() {
    const state = await storage.get();
    if (!state.authenticated || !state.accessToken) return null;
    if (!isExpiringSoon(state.tokenExpiresAt)) {
      return state.accessToken;
    }
    await removeCachedToken(state.accessToken);
    const newToken = await requestToken(state.scopes, false);
    if (!newToken) {
      await storage.clear();
      return null;
    }
    const refreshed = {
      ...state,
      accessToken: newToken,
      tokenExpiresAt: Date.now() + TOKEN_LIFETIME_MS
    };
    await storage.set(refreshed);
    return newToken;
  }
  async function hasGoogleScopes(requiredScopes) {
    const state = await storage.get();
    if (!state.authenticated) return false;
    return scopesInclude(state.scopes, normalizeScopeInput(requiredScopes));
  }
  async function googleFetch(url, init) {
    const token = await getValidAccessToken();
    if (!token) {
      return { ok: false, status: 401, statusText: "Unauthorized", headers: {}, bodyText: "", error: "Not authenticated" };
    }
    let headersInit;
    if (init?.headers) {
      if (Array.isArray(init.headers)) {
        headersInit = init.headers;
      } else {
        headersInit = init.headers;
      }
    }
    const headers = new Headers(headersInit);
    headers.set("Authorization", `Bearer ${token}`);
    let body;
    if (init?.body) {
      const b = init.body;
      if (typeof b === "object" && "__binary" in b && b.__binary === true) {
        const binary = atob(b.base64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
          bytes[i] = binary.charCodeAt(i);
        }
        body = bytes;
      } else {
        body = b;
      }
    }
    try {
      const response = await fetch(url, {
        method: init?.method,
        headers,
        body,
        redirect: init?.redirect,
        credentials: init?.credentials,
        cache: init?.cache,
        referrer: init?.referrer,
        referrerPolicy: init?.referrerPolicy,
        integrity: init?.integrity,
        keepalive: init?.keepalive
      });
      const bodyText = await response.text();
      const responseHeaders = {};
      response.headers.forEach((v, k) => {
        responseHeaders[k] = v;
      });
      return { ok: response.ok, status: response.status, statusText: response.statusText, headers: responseHeaders, bodyText };
    } catch (err) {
      return { ok: false, status: 0, statusText: "Network Error", headers: {}, bodyText: "", error: String(err) };
    }
  }

  // src/background/googleHandlers.ts
  async function handleGoogleAuth(scopes, broadcast2) {
    const state = await authenticateGoogle(scopes);
    const publicState = getPublicAuthState(state);
    broadcast2({ type: BG_EVT.GOOGLE_AUTH_UPDATED, payload: publicState });
    return { ok: state.authenticated, state: publicState };
  }
  async function handleGoogleLogout(broadcast2) {
    await logoutGoogle();
    const publicState = { authenticated: false, email: null, scopes: [] };
    broadcast2({ type: BG_EVT.GOOGLE_AUTH_UPDATED, payload: publicState });
    return { ok: true };
  }
  async function handleGoogleGetState() {
    const state = await storage.get();
    return { ok: true, state: getPublicAuthState(state) };
  }
  async function handleGoogleHasScopes(scopes) {
    const has = await hasGoogleScopes(scopes);
    return { ok: true, hasScopes: has };
  }
  async function handleGoogleFetch(payload) {
    const result = await googleFetch(payload.url, payload.init);
    return { ...result, requestId: payload.requestId };
  }

  // src/shared/keys.ts
  function getConfiguredKeyNames(env) {
    return Object.keys(env).filter((name) => env[name]?.trim());
  }

  // src/background/settingsHandlers.ts
  async function handleGetSettings() {
    const settings = await getSettings();
    return { ok: true, settings };
  }
  async function handleSetSettings(newSettings, broadcast2) {
    await setSettings(newSettings);
    broadcast2({ type: BG_EVT.SETTINGS_UPDATED });
    return { ok: true };
  }
  async function handleGetLogs() {
    const logs = await getLogs();
    return { ok: true, logs };
  }
  async function handleClearLogs(broadcast2) {
    await clearLogs();
    broadcast2({ type: BG_EVT.LOGS_UPDATED });
    return { ok: true };
  }
  async function handleIsKeySet(keyName) {
    const settings = await getSettings();
    const isSet = !!(keyName && settings.env[keyName]?.trim());
    return { ok: true, isSet };
  }
  async function handleGetKeyNames() {
    const settings = await getSettings();
    const keys = getConfiguredKeyNames(settings.env);
    return { ok: true, keys };
  }
  async function handleGetDomainStatus(domain) {
    if (!domain) {
      return { ok: false, error: "No domain provided", status: {} };
    }
    const settings = await getSettings();
    const pref = await getDomainPreference(domain);
    const hasApiKeys = Object.values(settings.env).some((v) => v?.trim());
    let domainEnabled = false;
    let domainSource = "default";
    if (pref) {
      domainEnabled = pref.enabled;
      domainSource = pref.source;
    }
    const originAllowed = true;
    const ready = domainEnabled && originAllowed;
    let reason = "";
    if (!domainEnabled) {
      reason = domainSource === "default" ? 'Bridge is disabled for this domain. Enable it in the extension or add <meta name="franzai-bridge" content="enabled"> to your page.' : "Bridge was disabled by user for this domain.";
    } else if (!hasApiKeys) {
      reason = "No API keys configured. Add keys in extension settings.";
    } else {
      reason = "Bridge is ready.";
    }
    const status = {
      installed: true,
      version: BRIDGE_VERSION,
      domainEnabled,
      domainSource,
      originAllowed,
      hasApiKeys,
      ready,
      reason
    };
    return { ok: true, status };
  }
  async function handleSetDomainEnabled(domain, enabled, broadcast2) {
    if (!domain) {
      return { ok: false, error: "No domain provided" };
    }
    await setDomainPreference(domain, enabled, "user");
    broadcast2({ type: BG_EVT.DOMAIN_PREFS_UPDATED });
    return { ok: true };
  }
  async function handleGetAllDomainPrefs() {
    const prefs = await getDomainPreferences();
    return { ok: true, prefs };
  }
  async function handleReportMetaTag(domain, enabled, broadcast2) {
    if (!domain) {
      return { ok: false, error: "No domain provided" };
    }
    await setDomainPreference(domain, enabled, "meta");
    broadcast2({ type: BG_EVT.DOMAIN_PREFS_UPDATED });
    return { ok: true };
  }
  async function handleRemoveDomainPref(domain, broadcast2) {
    if (!domain) {
      return { ok: false, error: "No domain provided" };
    }
    await removeDomainPreference(domain);
    broadcast2({ type: BG_EVT.DOMAIN_PREFS_UPDATED });
    return { ok: true };
  }

  // src/background.ts
  var log3 = createLogger("bg");
  var ports = /* @__PURE__ */ new Set();
  var autoOpenedTabs = /* @__PURE__ */ new Set();
  function broadcast(evt) {
    for (const port of ports) {
      try {
        port.postMessage(evt);
      } catch {
      }
    }
  }
  async function maybeAutoOpenSidepanel(tabId) {
    if (!tabId) return;
    if (autoOpenedTabs.has(tabId)) return;
    autoOpenedTabs.add(tabId);
    try {
      log3.info("Auto-opening sidepanel on first request for tab", tabId);
      await chrome.sidePanel.open({ tabId });
    } catch (e) {
      log3.warn("Could not auto-open sidepanel", e);
    }
  }
  chrome.runtime.onInstalled.addListener(async (details) => {
    log3.info("Extension installed/updated:", details.reason);
    try {
      const settings = await getSettings();
      await setSettings(settings);
    } catch (e) {
      log3.error("onInstalled failed", e);
    }
    await chrome.sidePanel.setOptions({ enabled: true });
    if (details.reason === "install") {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab?.id) {
          log3.info("Opening sidepanel after install for tab", tab.id);
          await chrome.sidePanel.open({ tabId: tab.id });
        }
      } catch (e) {
        log3.warn("Could not auto-open sidepanel after install", e);
      }
    }
  });
  chrome.runtime.onConnect.addListener((port) => {
    if (port.name !== "FRANZAI_SIDEPANEL" && port.name !== "FRANZAI_CONTENT") return;
    ports.add(port);
    port.onDisconnect.addListener(() => ports.delete(port));
  });
  chrome.action.onClicked.addListener(async (tab) => {
    log3.info("Extension icon clicked, opening sidepanel for tab", tab.id);
    if (tab.id) {
      try {
        await chrome.sidePanel.open({ tabId: tab.id });
      } catch (e) {
        log3.error("Failed to open sidepanel", e);
      }
    }
  });
  chrome.tabs.onRemoved.addListener((tabId) => {
    autoOpenedTabs.delete(tabId);
  });
  chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    if (changeInfo.status !== "complete" || !tab.url) return;
    if (!tab.url.startsWith("http://") && !tab.url.startsWith("https://")) return;
    try {
      const url = new URL(tab.url);
      const domain = url.hostname;
      const pref = await getDomainPreference(domain);
      if (pref?.enabled) {
        maybeAutoOpenSidepanel(tabId);
      }
    } catch {
    }
  });
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    (async () => {
      try {
        switch (msg.type) {
          case BG_MSG.GET_SETTINGS:
            sendResponse(await handleGetSettings());
            return;
          case BG_MSG.SET_SETTINGS:
            sendResponse(await handleSetSettings(msg.payload, broadcast));
            return;
          case BG_MSG.GET_LOGS:
            sendResponse(await handleGetLogs());
            return;
          case BG_MSG.CLEAR_LOGS:
            sendResponse(await handleClearLogs(broadcast));
            return;
          case BG_MSG.FETCH_ABORT:
            if (msg.payload?.requestId) abortFetch(msg.payload.requestId);
            sendResponse({ ok: true });
            return;
          case BG_MSG.IS_KEY_SET:
            sendResponse(await handleIsKeySet(msg.payload?.keyName ?? ""));
            return;
          case BG_MSG.GET_KEY_NAMES:
            sendResponse(await handleGetKeyNames());
            return;
          case BG_MSG.GET_DOMAIN_STATUS:
            sendResponse(await handleGetDomainStatus(msg.payload?.domain ?? ""));
            return;
          case BG_MSG.SET_DOMAIN_ENABLED: {
            const { domain, enabled } = msg.payload ?? {};
            sendResponse(await handleSetDomainEnabled(domain ?? "", enabled ?? false, broadcast));
            return;
          }
          case BG_MSG.GET_ALL_DOMAIN_PREFS:
            sendResponse(await handleGetAllDomainPrefs());
            return;
          case BG_MSG.REPORT_META_TAG: {
            const { domain, enabled } = msg.payload ?? {};
            const result = await handleReportMetaTag(domain ?? "", enabled ?? false, broadcast);
            if (enabled && sender.tab?.id) {
              maybeAutoOpenSidepanel(sender.tab.id);
            }
            sendResponse(result);
            return;
          }
          case BG_MSG.REMOVE_DOMAIN_PREF:
            sendResponse(await handleRemoveDomainPref(msg.payload?.domain ?? "", broadcast));
            return;
          case BG_MSG.GOOGLE_AUTH:
            sendResponse(await handleGoogleAuth(msg.payload?.scopes ?? [], broadcast));
            return;
          case BG_MSG.GOOGLE_LOGOUT:
            sendResponse(await handleGoogleLogout(broadcast));
            return;
          case BG_MSG.GOOGLE_GET_STATE:
            sendResponse(await handleGoogleGetState());
            return;
          case BG_MSG.GOOGLE_HAS_SCOPES:
            sendResponse(await handleGoogleHasScopes(msg.payload?.scopes ?? []));
            return;
          case BG_MSG.GOOGLE_FETCH:
            sendResponse(await handleGoogleFetch(msg.payload));
            return;
          case BG_MSG.FETCH: {
            const payload = msg.payload;
            const tabId = sender.tab?.id;
            const result = await handleFetch(payload, tabId, broadcast);
            maybeAutoOpenSidepanel(tabId);
            sendResponse(result);
            return;
          }
          default: {
            const unknown = msg.type;
            log3.warn("Unknown message type", unknown);
            sendResponse({ ok: false, error: "Unknown message type" });
            return;
          }
        }
      } catch (e) {
        const message = e instanceof Error ? e.message : String(e);
        log3.error("Unhandled error in onMessage", e);
        sendResponse({ ok: false, error: `Internal error: ${message}` });
      }
    })();
    return true;
  });
})();
//# sourceMappingURL=background.js.map
