"use strict";
(() => {
  // src/shared/constants.ts
  var BRIDGE_SOURCE = "FRANZAI_BRIDGE";
  var BRIDGE_VERSION = "2.0.66";
  var BRIDGE_TIMEOUT_MS = 3e4;
  var MAX_BODY_BYTES = 5 * 1024 * 1024;

  // src/shared/messages.ts
  var PAGE_MSG = {
    FETCH_REQUEST: "FETCH_REQUEST",
    FETCH_ABORT: "FETCH_ABORT",
    FETCH_RESPONSE: "FETCH_RESPONSE",
    BRIDGE_READY: "BRIDGE_READY",
    KEY_CHECK_REQUEST: "KEY_CHECK_REQUEST",
    KEY_CHECK_RESPONSE: "KEY_CHECK_RESPONSE",
    KEYS_REQUEST: "KEYS_REQUEST",
    KEYS_RESPONSE: "KEYS_RESPONSE",
    KEYS_UPDATE: "KEYS_UPDATE",
    STATUS_REQUEST: "STATUS_REQUEST",
    STATUS_RESPONSE: "STATUS_RESPONSE",
    DOMAIN_ENABLED_UPDATE: "DOMAIN_ENABLED_UPDATE",
    // Google OAuth page messages
    GOOGLE_AUTH_REQUEST: "GOOGLE_AUTH_REQUEST",
    GOOGLE_AUTH_RESPONSE: "GOOGLE_AUTH_RESPONSE",
    GOOGLE_LOGOUT_REQUEST: "GOOGLE_LOGOUT_REQUEST",
    GOOGLE_LOGOUT_RESPONSE: "GOOGLE_LOGOUT_RESPONSE",
    GOOGLE_STATE_REQUEST: "GOOGLE_STATE_REQUEST",
    GOOGLE_STATE_RESPONSE: "GOOGLE_STATE_RESPONSE",
    GOOGLE_HAS_SCOPES_REQUEST: "GOOGLE_HAS_SCOPES_REQUEST",
    GOOGLE_HAS_SCOPES_RESPONSE: "GOOGLE_HAS_SCOPES_RESPONSE",
    GOOGLE_FETCH_REQUEST: "GOOGLE_FETCH_REQUEST",
    GOOGLE_FETCH_RESPONSE: "GOOGLE_FETCH_RESPONSE",
    GOOGLE_AUTH_UPDATE: "GOOGLE_AUTH_UPDATE"
  };

  // src/shared/logger.ts
  var LEVELS = {
    debug: 10,
    info: 20,
    warn: 30,
    error: 40,
    silent: 99
  };
  function resolveLevel(level) {
    if (level) return level;
    const raw = globalThis.__FRANZAI_LOG_LEVEL__;
    if (typeof raw === "string" && raw in LEVELS) return raw;
    return "info";
  }
  function createLogger(scope, level, c = console) {
    const chosen = resolveLevel(level);
    const min = LEVELS[chosen];
    const prefix = `[FranzAI Bridge/${scope}]`;
    return {
      debug: (...args) => {
        if (min <= LEVELS.debug) c.debug(prefix, ...args);
      },
      info: (...args) => {
        if (min <= LEVELS.info) c.info(prefix, ...args);
      },
      warn: (...args) => {
        if (min <= LEVELS.warn) c.warn(prefix, ...args);
      },
      error: (...args) => {
        if (min <= LEVELS.error) c.error(prefix, ...args);
      },
      log: (...args) => {
        if (min <= LEVELS.info) c.log(prefix, ...args);
      }
    };
  }

  // src/shared/ids.ts
  function makeId(prefix) {
    if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
      return `${prefix}_${crypto.randomUUID()}`;
    }
    return `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  }

  // src/shared/domainCache.ts
  function initDomainStatusCache() {
    return {
      status: null,
      enabledOverride: null
    };
  }
  function getCachedDomainEnabled(cache) {
    if (cache.enabledOverride !== null) return cache.enabledOverride;
    return cache.status?.domainEnabled ?? null;
  }
  function setDomainStatus(cache, status) {
    cache.status = status;
    cache.enabledOverride = null;
  }
  function applyDomainEnabledUpdate(cache, payload) {
    const enabled = payload.enabled ?? false;
    if (cache.status) {
      cache.status.domainEnabled = enabled;
      const source = payload.source;
      if (source === "user" || source === "meta" || source === "default") {
        cache.status.domainSource = source;
      } else {
        cache.status.domainSource = "default";
      }
      cache.enabledOverride = null;
      return;
    }
    cache.enabledOverride = enabled;
  }

  // src/injected.ts
  var win = window;
  var ALREADY_INSTALLED = !!win.__franzaiBridgeInstalled;
  var NATIVE_FETCH = ALREADY_INSTALLED ? win.__franzaiNativeFetch : window.fetch.bind(window);
  var NATIVE_REQUEST = ALREADY_INSTALLED ? win.__franzaiNativeRequest : window.Request;
  var NATIVE_FETCH_DESCRIPTOR = ALREADY_INSTALLED ? win.__franzaiNativeFetchDescriptor ?? null : Object.getOwnPropertyDescriptor(window, "fetch") ?? null;
  var NATIVE_REQUEST_DESCRIPTOR = ALREADY_INSTALLED ? win.__franzaiNativeRequestDescriptor ?? null : Object.getOwnPropertyDescriptor(window, "Request") ?? null;
  if (!ALREADY_INSTALLED) {
    Object.defineProperties(win, {
      __franzaiNativeFetch: {
        value: NATIVE_FETCH,
        writable: false,
        configurable: false,
        enumerable: false
      },
      __franzaiNativeRequest: {
        value: NATIVE_REQUEST,
        writable: false,
        configurable: false,
        enumerable: false
      },
      __franzaiNativeFetchDescriptor: {
        value: NATIVE_FETCH_DESCRIPTOR,
        writable: false,
        configurable: false,
        enumerable: false
      },
      __franzaiNativeRequestDescriptor: {
        value: NATIVE_REQUEST_DESCRIPTOR,
        writable: false,
        configurable: false,
        enumerable: false
      },
      __franzaiBridgeInstalled: {
        value: true,
        writable: false,
        configurable: false,
        enumerable: false
      }
    });
  }
  var log = createLogger("page");
  var BRIDGE_DISABLED_MESSAGE = 'Bridge is disabled for this domain. Enable it in the extension or add <meta name="franzai-bridge" content="enabled"> to your page.';
  var domainStatusCache = initDomainStatusCache();
  var domainStatusPromise = null;
  var cachedKeyNames = [];
  var keysPromise = null;
  function updateKeyCache(keys) {
    cachedKeyNames = keys;
    if (win.franzai) {
      win.franzai.keys = [...cachedKeyNames];
    }
  }
  async function refreshKeyNames() {
    if (keysPromise) return keysPromise;
    keysPromise = new Promise((resolve) => {
      const keysId = makeId("keys");
      const timeoutId = window.setTimeout(() => {
        window.removeEventListener("message", onMessage);
        keysPromise = null;
        resolve(cachedKeyNames);
      }, 5e3);
      const onMessage = (ev) => {
        if (ev.source !== window) return;
        const data = ev.data;
        if (!data || data.source !== BRIDGE_SOURCE) return;
        if (data.type !== PAGE_MSG.KEYS_RESPONSE) return;
        if (data.payload?.keysId !== keysId) return;
        clearTimeout(timeoutId);
        window.removeEventListener("message", onMessage);
        keysPromise = null;
        const nextKeys = Array.isArray(data.payload?.keys) ? data.payload.keys : [];
        updateKeyCache(nextKeys);
        resolve(cachedKeyNames);
      };
      window.addEventListener("message", onMessage);
      window.postMessage(
        {
          source: BRIDGE_SOURCE,
          type: PAGE_MSG.KEYS_REQUEST,
          payload: { keysId }
        },
        "*"
      );
    });
    return keysPromise;
  }
  async function fetchDomainStatus() {
    if (domainStatusPromise) return domainStatusPromise;
    domainStatusPromise = new Promise((resolve) => {
      const statusId = makeId("status");
      const timeoutId = window.setTimeout(() => {
        window.removeEventListener("message", onMessage);
        const fallback = {
          installed: true,
          version: BRIDGE_VERSION,
          domainEnabled: false,
          domainSource: "default",
          originAllowed: true,
          hasApiKeys: false,
          ready: false,
          reason: "Timeout waiting for status"
        };
        setDomainStatus(domainStatusCache, fallback);
        resolve(fallback);
      }, 3e3);
      const onMessage = (ev) => {
        if (ev.source !== window) return;
        const data = ev.data;
        if (!data || data.source !== BRIDGE_SOURCE) return;
        if (data.type !== PAGE_MSG.STATUS_RESPONSE) return;
        if (data.payload?.statusId !== statusId) return;
        clearTimeout(timeoutId);
        window.removeEventListener("message", onMessage);
        setDomainStatus(domainStatusCache, data.payload.status);
        resolve(data.payload.status);
      };
      window.addEventListener("message", onMessage);
      window.postMessage(
        {
          source: BRIDGE_SOURCE,
          type: PAGE_MSG.STATUS_REQUEST,
          payload: { statusId }
        },
        "*"
      );
    });
    const result = await domainStatusPromise;
    domainStatusPromise = null;
    return result;
  }
  async function ensureDomainStatus() {
    const status = await fetchDomainStatus();
    syncBridgeHooksFromCache();
    return status;
  }
  async function ensureDomainEnabled() {
    let enabled = getCachedDomainEnabled(domainStatusCache);
    if (enabled === null) {
      try {
        await ensureDomainStatus();
        enabled = getCachedDomainEnabled(domainStatusCache);
      } catch {
        enabled = null;
      }
    }
    return enabled === true;
  }
  window.addEventListener("message", (ev) => {
    if (ev.source !== window) return;
    const data = ev.data;
    if (!data || data.source !== BRIDGE_SOURCE) return;
    if (data.type !== PAGE_MSG.DOMAIN_ENABLED_UPDATE) return;
    const enabled = data.payload?.enabled ?? false;
    log.info("DOMAIN_ENABLED_UPDATE received:", enabled, "cache status:", !!domainStatusCache.status);
    applyDomainEnabledUpdate(domainStatusCache, data.payload ?? {});
    log.info("Domain enabled cache updated:", getCachedDomainEnabled(domainStatusCache));
    syncBridgeHooksFromCache();
  });
  window.addEventListener("message", (ev) => {
    if (ev.source !== window) return;
    const data = ev.data;
    if (!data || data.source !== BRIDGE_SOURCE) return;
    if (data.type !== PAGE_MSG.KEYS_UPDATE) return;
    if (Array.isArray(data.payload?.keys)) {
      updateKeyCache(data.payload.keys);
    }
  });
  var googleAuthState = { authenticated: false, email: null, scopes: [] };
  function updateGoogleAuthState(state) {
    googleAuthState = state;
  }
  window.addEventListener("message", (ev) => {
    if (ev.source !== window) return;
    const data = ev.data;
    if (!data || data.source !== BRIDGE_SOURCE) return;
    if (data.type !== PAGE_MSG.GOOGLE_AUTH_UPDATE) return;
    if (data.payload) {
      updateGoogleAuthState(data.payload);
      log.info("Google auth state updated:", data.payload.authenticated, data.payload.email);
    }
  });
  var REQUEST_META = Symbol.for("franzaiBridgeMeta");
  var textEncoder = new TextEncoder();
  function normalizeMode(mode) {
    if (mode === "auto" || mode === "always" || mode === "off") return mode;
    return void 0;
  }
  function getBridgeConfig() {
    const existing = win.__franzaiBridgeConfig;
    const config = existing && typeof existing === "object" ? existing : {};
    const normalized = normalizeMode(config.mode) ?? "always";
    const lockHooks = config.lockHooks !== false;
    const finalConfig = {
      mode: normalized,
      lockHooks
    };
    win.__franzaiBridgeConfig = finalConfig;
    return finalConfig;
  }
  var bridgeConfig = getBridgeConfig();
  function setRequestMode(request, mode) {
    if (!mode) return;
    try {
      Object.defineProperty(request, REQUEST_META, {
        value: mode,
        enumerable: false
      });
    } catch {
    }
  }
  function getRequestMode(request) {
    const meta = request;
    return normalizeMode(meta[REQUEST_META]);
  }
  function createAbortError(message) {
    try {
      return new DOMException(message, "AbortError");
    } catch {
      const err = new Error(message);
      err.name = "AbortError";
      return err;
    }
  }
  function isAbortError(error) {
    return error instanceof Error && error.name === "AbortError";
  }
  function resolveUrl(input) {
    if (typeof input === "string") return new URL(input, window.location.href).toString();
    if (input instanceof URL) return new URL(input.toString(), window.location.href).toString();
    return new URL(input.url, window.location.href).toString();
  }
  function headersToLite(headers) {
    if (!headers) return void 0;
    if (headers instanceof Headers) {
      const entries = [];
      headers.forEach((value, key) => entries.push([key, value]));
      return entries;
    }
    if (Array.isArray(headers)) return headers;
    return headers;
  }
  function modeFromInit(init) {
    return normalizeMode(init?.franzai?.mode);
  }
  function resolveBridgeMode(input, init) {
    const initMode = modeFromInit(init);
    if (initMode) return initMode;
    if (input instanceof Request) {
      const requestMode = getRequestMode(input);
      if (requestMode) return requestMode;
    }
    return bridgeConfig.mode ?? "always";
  }
  function enforceMaxBytes(bytes) {
    if (bytes > MAX_BODY_BYTES) {
      throw new Error(`Request body too large (${bytes} bytes). Max is ${MAX_BODY_BYTES} bytes.`);
    }
  }
  function byteLengthOfString(text) {
    return textEncoder.encode(text).byteLength;
  }
  function isTextualContentType(contentType) {
    if (!contentType) return false;
    const ct = contentType.toLowerCase();
    return ct.startsWith("text/") || ct.includes("json") || ct.includes("xml") || ct.includes("x-www-form-urlencoded");
  }
  function maybeSetContentType(headers, value) {
    if (!value) return;
    if (!headers.has("content-type")) headers.set("content-type", value);
  }
  function toUint8Array(buffer) {
    const bytes = new Uint8Array(buffer);
    enforceMaxBytes(bytes.byteLength);
    return bytes;
  }
  function uint8ArrayToBase64(bytes) {
    let binary = "";
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }
  function toBinaryBody(bytes) {
    return {
      __binary: true,
      base64: uint8ArrayToBase64(bytes),
      byteLength: bytes.byteLength
    };
  }
  async function bodyToPayload(body, headers) {
    if (typeof body === "string") {
      enforceMaxBytes(byteLengthOfString(body));
      return body;
    }
    if (body instanceof URLSearchParams) {
      const text = body.toString();
      maybeSetContentType(headers, "application/x-www-form-urlencoded;charset=UTF-8");
      enforceMaxBytes(byteLengthOfString(text));
      return text;
    }
    if (typeof FormData !== "undefined" && body instanceof FormData) {
      const response = new Response(body);
      maybeSetContentType(headers, response.headers.get("content-type"));
      return toBinaryBody(toUint8Array(await response.arrayBuffer()));
    }
    if (typeof Blob !== "undefined" && body instanceof Blob) {
      if (isTextualContentType(body.type)) {
        const text = await body.text();
        maybeSetContentType(headers, body.type);
        enforceMaxBytes(byteLengthOfString(text));
        return text;
      }
      maybeSetContentType(headers, body.type);
      return toBinaryBody(toUint8Array(await body.arrayBuffer()));
    }
    if (body instanceof ArrayBuffer) {
      return toBinaryBody(toUint8Array(body));
    }
    if (ArrayBuffer.isView(body)) {
      const bytes = new Uint8Array(body.buffer, body.byteOffset, body.byteLength);
      enforceMaxBytes(bytes.byteLength);
      return toBinaryBody(bytes);
    }
    if (typeof ReadableStream !== "undefined" && body instanceof ReadableStream) {
      const response = new Response(body);
      return toBinaryBody(toUint8Array(await response.arrayBuffer()));
    }
    throw new Error("FranzAI Bridge cannot forward this body type");
  }
  async function readRequestBody(request, headers) {
    if (!request.body) return void 0;
    const contentType = headers.get("content-type");
    if (isTextualContentType(contentType)) {
      try {
        const text = await request.clone().text();
        enforceMaxBytes(byteLengthOfString(text));
        return text;
      } catch {
      }
    }
    try {
      return toBinaryBody(toUint8Array(await request.clone().arrayBuffer()));
    } catch {
      throw new Error(
        "FranzAI Bridge cannot forward a locked or unreadable request body"
      );
    }
  }
  async function requestToLite(input, init) {
    const baseSignal = init?.signal;
    if (typeof input === "string" || input instanceof URL) {
      const headers2 = new Headers(init?.headers);
      const bodyPayload2 = init?.body != null ? await bodyToPayload(init.body, headers2) : void 0;
      return {
        url: resolveUrl(input),
        init: {
          method: init?.method,
          headers: headersToLite(headers2),
          body: bodyPayload2,
          redirect: init?.redirect,
          credentials: init?.credentials,
          cache: init?.cache,
          referrer: init?.referrer,
          referrerPolicy: init?.referrerPolicy,
          integrity: init?.integrity,
          keepalive: init?.keepalive
        },
        signal: baseSignal ?? void 0
      };
    }
    const req = input;
    const headers = new Headers(init?.headers ?? req.headers);
    const bodyPayload = init?.body != null ? await bodyToPayload(init.body, headers) : await readRequestBody(req, headers);
    return {
      url: resolveUrl(req.url),
      init: {
        method: init?.method ?? req.method,
        headers: headersToLite(headers),
        body: bodyPayload,
        redirect: init?.redirect ?? req.redirect,
        credentials: init?.credentials ?? req.credentials,
        cache: init?.cache ?? req.cache,
        referrer: init?.referrer ?? req.referrer,
        referrerPolicy: init?.referrerPolicy ?? req.referrerPolicy,
        integrity: init?.integrity ?? req.integrity,
        keepalive: init?.keepalive ?? req.keepalive
      },
      signal: baseSignal ?? req.signal
    };
  }
  var nativeFetch = NATIVE_FETCH;
  var nativeRequest = NATIVE_REQUEST;
  var originalFetchDescriptor = NATIVE_FETCH_DESCRIPTOR;
  var originalRequestDescriptor = NATIVE_REQUEST_DESCRIPTOR;
  var hookState = { installed: false };
  function restoreNativeFetch() {
    if (originalFetchDescriptor) {
      try {
        Object.defineProperty(window, "fetch", originalFetchDescriptor);
        return;
      } catch {
      }
    }
    try {
      delete window.fetch;
    } catch {
    }
    try {
      window.fetch = nativeFetch;
    } catch {
    }
  }
  function restoreNativeRequest() {
    if (originalRequestDescriptor) {
      try {
        Object.defineProperty(window, "Request", originalRequestDescriptor);
        return;
      } catch {
      }
    }
    try {
      delete window.Request;
    } catch {
    }
    try {
      window.Request = nativeRequest;
    } catch {
    }
  }
  function installFetchHook() {
    const hookDescriptor = {
      value: hookedFetch,
      enumerable: true,
      writable: !bridgeConfig.lockHooks,
      configurable: true
    };
    try {
      Object.defineProperty(window, "fetch", hookDescriptor);
    } catch {
      window.fetch = hookedFetch;
    }
    if (!bridgeConfig.lockHooks) return;
    queueMicrotask(() => {
      if (window.fetch !== hookedFetch) {
        log.error("CRITICAL: fetch hook was overwritten immediately after installation!");
        try {
          Object.defineProperty(window, "fetch", hookDescriptor);
          log.info("Recovered fetch hook with guarded lock");
        } catch (e) {
          log.error("Failed to recover fetch hook", e);
        }
      }
    });
  }
  function installBridgeHooks() {
    if (hookState.installed) return;
    installRequestHook();
    installFetchHook();
    hookState.installed = true;
    window.postMessage(
      {
        source: BRIDGE_SOURCE,
        type: PAGE_MSG.BRIDGE_READY,
        payload: { version: BRIDGE_VERSION }
      },
      "*"
    );
  }
  function uninstallBridgeHooks() {
    if (!hookState.installed) return;
    hookState.installed = false;
    restoreNativeRequest();
    restoreNativeFetch();
    const w = window;
    w.__franzaiRequestHookInstalled = false;
  }
  function setBridgeActive(active) {
    if (active) {
      installBridgeHooks();
      return;
    }
    uninstallBridgeHooks();
  }
  function syncBridgeHooksFromCache() {
    setBridgeActive(getCachedDomainEnabled(domainStatusCache) === true);
  }
  function isCrossOrigin(input) {
    try {
      const url = new URL(resolveUrl(input), window.location.href);
      return url.origin !== window.location.origin;
    } catch {
      return false;
    }
  }
  function shouldUseBridgeForRequest(input, init) {
    const mode = resolveBridgeMode(input, init);
    if (mode === "off") return false;
    if (mode === "always") return true;
    return isCrossOrigin(input);
  }
  var franzai = {
    version: BRIDGE_VERSION,
    keys: [],
    async ping() {
      return { ok: true, version: franzai.version };
    },
    setMode(mode) {
      bridgeConfig.mode = normalizeMode(mode) ?? "auto";
      return bridgeConfig.mode;
    },
    getMode() {
      return bridgeConfig.mode ?? "auto";
    },
    async isKeySet(keyName) {
      if (!keyName || typeof keyName !== "string") return false;
      const checkId = makeId("keycheck");
      return new Promise((resolve) => {
        const timeoutId = window.setTimeout(() => {
          window.removeEventListener("message", onMessage);
          resolve(false);
        }, 5e3);
        const onMessage = (ev) => {
          if (ev.source !== window) return;
          const data = ev.data;
          if (!data || data.source !== BRIDGE_SOURCE) return;
          if (data.type !== PAGE_MSG.KEY_CHECK_RESPONSE) return;
          if (data.payload?.checkId !== checkId) return;
          clearTimeout(timeoutId);
          window.removeEventListener("message", onMessage);
          resolve(data.payload.isSet);
        };
        window.addEventListener("message", onMessage);
        window.postMessage(
          {
            source: BRIDGE_SOURCE,
            type: PAGE_MSG.KEY_CHECK_REQUEST,
            payload: { checkId, keyName }
          },
          "*"
        );
      });
    },
    async hasApiKey(keyName) {
      return franzai.isKeySet(keyName);
    },
    async getStatus() {
      if (domainStatusCache.status) {
        return domainStatusCache.status;
      }
      return ensureDomainStatus();
    },
    async fetch(input, init) {
      if (!await ensureDomainEnabled()) {
        throw new Error(BRIDGE_DISABLED_MESSAGE);
      }
      const lite = await requestToLite(input, init);
      if (lite.signal?.aborted) {
        throw createAbortError("The operation was aborted");
      }
      const requestId = makeId("req");
      const req = { requestId, url: lite.url, init: lite.init };
      const resp = await new Promise((resolve, reject) => {
        let done = false;
        const cleanup = () => {
          window.removeEventListener("message", onMessage);
          if (lite.signal) lite.signal.removeEventListener("abort", onAbort);
          clearTimeout(timeoutId);
        };
        const finishResolve = (value) => {
          if (done) return;
          done = true;
          cleanup();
          resolve(value);
        };
        const finishReject = (error) => {
          if (done) return;
          done = true;
          cleanup();
          reject(error);
        };
        const onAbort = () => {
          window.postMessage(
            {
              source: BRIDGE_SOURCE,
              type: PAGE_MSG.FETCH_ABORT,
              payload: { requestId }
            },
            "*"
          );
          finishReject(createAbortError("The operation was aborted"));
        };
        const onMessage = (ev) => {
          if (ev.source !== window) return;
          const data = ev.data;
          if (!data || data.source !== BRIDGE_SOURCE) return;
          if (data.type !== PAGE_MSG.FETCH_RESPONSE) return;
          const payload = data.payload;
          const responseObj = payload?.response;
          if (!responseObj || responseObj.requestId !== requestId) return;
          finishResolve(payload);
        };
        const timeoutId = window.setTimeout(() => {
          finishResolve({
            ok: false,
            error: `Timed out waiting for FranzAI Bridge response after ${BRIDGE_TIMEOUT_MS}ms. Check that the extension is installed, enabled, and that this origin is allowed.`
          });
        }, BRIDGE_TIMEOUT_MS);
        window.addEventListener("message", onMessage);
        if (lite.signal) lite.signal.addEventListener("abort", onAbort, { once: true });
        window.postMessage(
          {
            source: BRIDGE_SOURCE,
            type: PAGE_MSG.FETCH_REQUEST,
            payload: req
          },
          "*"
        );
      });
      if (!resp.ok || !resp.response) {
        const msg = resp.error ?? resp.response?.error ?? "Unknown error";
        log.warn("Bridge fetch failed", msg);
        throw new Error(`FranzAI Bridge fetch failed: ${msg}`);
      }
      const r = resp.response;
      return new Response(r.bodyText, {
        status: r.status,
        statusText: r.statusText,
        headers: r.headers
      });
    },
    // Google OAuth API
    google: {
      async auth(scopes) {
        const scopeArray = scopes ? Array.isArray(scopes) ? scopes : [scopes] : [];
        const authId = makeId("gauth");
        return new Promise((resolve) => {
          const timeoutId = window.setTimeout(() => {
            window.removeEventListener("message", onMessage);
            resolve({ authenticated: false, email: null, scopes: [] });
          }, 3e4);
          const onMessage = (ev) => {
            if (ev.source !== window) return;
            const data = ev.data;
            if (!data || data.source !== BRIDGE_SOURCE || data.type !== PAGE_MSG.GOOGLE_AUTH_RESPONSE) return;
            if (data.payload?.authId !== authId) return;
            clearTimeout(timeoutId);
            window.removeEventListener("message", onMessage);
            const state = data.payload.state ?? { authenticated: false, email: null, scopes: [] };
            updateGoogleAuthState(state);
            resolve(state);
          };
          window.addEventListener("message", onMessage);
          window.postMessage({ source: BRIDGE_SOURCE, type: PAGE_MSG.GOOGLE_AUTH_REQUEST, payload: { authId, scopes: scopeArray } }, "*");
        });
      },
      async logout() {
        const logoutId = makeId("glogout");
        return new Promise((resolve) => {
          const timeoutId = window.setTimeout(() => {
            window.removeEventListener("message", onMessage);
            resolve();
          }, 5e3);
          const onMessage = (ev) => {
            if (ev.source !== window) return;
            const data = ev.data;
            if (!data || data.source !== BRIDGE_SOURCE || data.type !== PAGE_MSG.GOOGLE_LOGOUT_RESPONSE) return;
            if (data.payload?.logoutId !== logoutId) return;
            clearTimeout(timeoutId);
            window.removeEventListener("message", onMessage);
            updateGoogleAuthState({ authenticated: false, email: null, scopes: [] });
            resolve();
          };
          window.addEventListener("message", onMessage);
          window.postMessage({ source: BRIDGE_SOURCE, type: PAGE_MSG.GOOGLE_LOGOUT_REQUEST, payload: { logoutId } }, "*");
        });
      },
      async fetch(url, init) {
        if (!await ensureDomainEnabled()) {
          throw new Error(BRIDGE_DISABLED_MESSAGE);
        }
        const requestId = makeId("gfetch");
        const liteInit = init ? {
          method: init.method,
          headers: headersToLite(init.headers),
          body: init.body ? await bodyToPayload(init.body, new Headers(init.headers)) : void 0
        } : void 0;
        const req = { requestId, url, init: liteInit };
        return new Promise((resolve, reject) => {
          const timeoutId = window.setTimeout(() => {
            window.removeEventListener("message", onMessage);
            reject(new Error("Google fetch timed out"));
          }, BRIDGE_TIMEOUT_MS);
          const onMessage = (ev) => {
            if (ev.source !== window) return;
            const data = ev.data;
            if (!data || data.source !== BRIDGE_SOURCE || data.type !== PAGE_MSG.GOOGLE_FETCH_RESPONSE) return;
            if (data.payload?.requestId !== requestId) return;
            clearTimeout(timeoutId);
            window.removeEventListener("message", onMessage);
            const resp = data.payload;
            if (!resp.ok && resp.error) {
              reject(new Error(resp.error));
              return;
            }
            resolve(new Response(resp.bodyText, {
              status: resp.status,
              statusText: resp.statusText,
              headers: resp.headers
            }));
          };
          window.addEventListener("message", onMessage);
          window.postMessage({ source: BRIDGE_SOURCE, type: PAGE_MSG.GOOGLE_FETCH_REQUEST, payload: req }, "*");
        });
      },
      async hasScopes(scopes) {
        const scopeArray = Array.isArray(scopes) ? scopes : [scopes];
        const scopesId = makeId("gscopes");
        return new Promise((resolve) => {
          const timeoutId = window.setTimeout(() => {
            window.removeEventListener("message", onMessage);
            resolve(false);
          }, 5e3);
          const onMessage = (ev) => {
            if (ev.source !== window) return;
            const data = ev.data;
            if (!data || data.source !== BRIDGE_SOURCE || data.type !== PAGE_MSG.GOOGLE_HAS_SCOPES_RESPONSE) return;
            if (data.payload?.scopesId !== scopesId) return;
            clearTimeout(timeoutId);
            window.removeEventListener("message", onMessage);
            resolve(data.payload.hasScopes);
          };
          window.addEventListener("message", onMessage);
          window.postMessage({ source: BRIDGE_SOURCE, type: PAGE_MSG.GOOGLE_HAS_SCOPES_REQUEST, payload: { scopesId, scopes: scopeArray } }, "*");
        });
      },
      async getState() {
        const stateId = makeId("gstate");
        return new Promise((resolve) => {
          const timeoutId = window.setTimeout(() => {
            window.removeEventListener("message", onMessage);
            resolve(googleAuthState);
          }, 5e3);
          const onMessage = (ev) => {
            if (ev.source !== window) return;
            const data = ev.data;
            if (!data || data.source !== BRIDGE_SOURCE || data.type !== PAGE_MSG.GOOGLE_STATE_RESPONSE) return;
            if (data.payload?.stateId !== stateId) return;
            clearTimeout(timeoutId);
            window.removeEventListener("message", onMessage);
            updateGoogleAuthState(data.payload.state);
            resolve(data.payload.state);
          };
          window.addEventListener("message", onMessage);
          window.postMessage({ source: BRIDGE_SOURCE, type: PAGE_MSG.GOOGLE_STATE_REQUEST, payload: { stateId } }, "*");
        });
      },
      get isAuthenticated() {
        return googleAuthState.authenticated;
      },
      get email() {
        return googleAuthState.email;
      },
      get scopes() {
        return [...googleAuthState.scopes];
      }
    }
  };
  async function hookedFetch(input, init) {
    if (!hookState.installed) {
      return nativeFetch(input, init);
    }
    const mode = resolveBridgeMode(input, init);
    if (!shouldUseBridgeForRequest(input, init)) {
      return nativeFetch(input, init);
    }
    let domainEnabled = getCachedDomainEnabled(domainStatusCache);
    log.info("hookedFetch check - cachedEnabled:", domainEnabled);
    if (domainEnabled === null) {
      try {
        await ensureDomainStatus();
        domainEnabled = getCachedDomainEnabled(domainStatusCache);
        log.info("hookedFetch after fetch - domainEnabled:", domainEnabled);
      } catch {
        log.info("Domain status fetch failed, using nativeFetch");
        return nativeFetch(input, init);
      }
    }
    if (domainEnabled !== true) {
      log.info("Domain not enabled, using nativeFetch");
      return nativeFetch(input, init);
    }
    try {
      return await franzai.fetch(input, init);
    } catch (e) {
      if (isAbortError(e)) throw e;
      if (mode === "always") throw e;
      const msg = e instanceof Error ? e.message : String(e);
      log.debug("Bridge fetch failed, falling back to native fetch", msg);
      try {
        return await nativeFetch(input, init);
      } catch {
        throw new Error(msg);
      }
    }
  }
  function installRequestHook() {
    const w = window;
    if (w.__franzaiRequestHookInstalled) return;
    w.__franzaiRequestHookInstalled = true;
    const FranzaiRequest = function(input, init) {
      const req = new nativeRequest(input, init);
      setRequestMode(req, modeFromInit(init));
      return req;
    };
    FranzaiRequest.prototype = nativeRequest.prototype;
    Object.setPrototypeOf(FranzaiRequest, nativeRequest);
    try {
      Object.defineProperty(window, "Request", {
        configurable: true,
        writable: true,
        value: FranzaiRequest
      });
    } catch {
      window.Request = FranzaiRequest;
    }
  }
  if (!ALREADY_INSTALLED) {
    Object.defineProperty(win, "franzai", {
      value: franzai,
      writable: false,
      configurable: false,
      enumerable: true
    });
    log.info("FranzAI Bridge installed", {
      version: franzai.version,
      mode: bridgeConfig.mode,
      locked: bridgeConfig.lockHooks
    });
    refreshKeyNames().catch(() => {
    });
    franzai.google.getState().catch(() => {
    });
    ensureDomainStatus().catch(() => {
    });
  }
})();
//# sourceMappingURL=injected.js.map
